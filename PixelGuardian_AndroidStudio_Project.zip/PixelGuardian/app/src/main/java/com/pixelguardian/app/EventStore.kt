package com.pixelguardian.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object EventStore {
    private const val PREF = "guardian_events"
    private const val KEY = "events"
    @Synchronized fun add(context: Context, message: String) {
        val prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val events = JSONArray(prefs.getString(KEY, "[]"))
        val item = JSONObject().put("time", System.currentTimeMillis()).put("message", message)
        val next = JSONArray().put(item)
        for (i in 0 until minOf(events.length(), 199)) next.put(events.getJSONObject(i))
        prefs.edit().putString(KEY, next.toString()).apply()
    }
    @Synchronized fun read(context: Context): String {
        val events = JSONArray(context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]"))
        if (events.length() == 0) return "No events recorded yet."
        val fmt = SimpleDateFormat("dd MMM yyyy, HH:mm:ss", Locale.getDefault())
        return (0 until events.length()).joinToString("\n\n") {
            val obj = events.getJSONObject(it)
            "${fmt.format(Date(obj.getLong("time")))}\n${obj.getString("message")}" 
        }
    }
    @Synchronized fun clear(context: Context) = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().remove(KEY).apply()
}
