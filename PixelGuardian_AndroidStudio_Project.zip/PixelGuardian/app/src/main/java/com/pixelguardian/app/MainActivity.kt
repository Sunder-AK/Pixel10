package com.pixelguardian.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var history: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 28)
            setBackgroundColor(Color.rgb(246, 248, 252))
        }
        fun text(value: String, size: Float): TextView = TextView(this).apply {
            text = value; textSize = size; setTextColor(Color.rgb(25, 40, 62)); setPadding(0, 0, 0, 18)
        }
        root.addView(text("🛡 Pixel Guardian", 26f))
        root.addView(text("Local anti-theft event monitor • v1.0", 14f))
        status = text("", 16f)
        root.addView(status)
        val start = Button(this).apply {
            text = "Start monitoring"
            setOnClickListener {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
                startForegroundService(Intent(this@MainActivity, GuardianService::class.java))
                refresh()
            }
        }
        root.addView(start)
        root.addView(Button(this).apply {
            text = "Stop monitoring"
            setOnClickListener { stopService(Intent(this@MainActivity, GuardianService::class.java)); status.postDelayed({ refresh() }, 250) }
        })
        root.addView(Button(this).apply { text = "Refresh events"; setOnClickListener { refresh() } })
        root.addView(Button(this).apply { text = "Clear event history"; setOnClickListener { EventStore.clear(this@MainActivity); refresh() } })
        root.addView(text("Security event history (stored only on this phone)", 18f))
        val scroll = ScrollView(this)
        history = text("", 14f)
        scroll.addView(history)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(text("Limitations: cannot block Quick Settings, shutdown, or forced restart. Events may be missed if Android stops the service. No location tracking or remote alerts.", 12f))
        setContentView(root)
    }
    override fun onResume() { super.onResume(); refresh() }
    private fun refresh() {
        status.text = if (GuardianService.running) "● Monitoring active" else "○ Monitoring stopped"
        history.text = EventStore.read(this)
    }
}
