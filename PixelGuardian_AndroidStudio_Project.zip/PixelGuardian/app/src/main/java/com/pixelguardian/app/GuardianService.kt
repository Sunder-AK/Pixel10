package com.pixelguardian.app

import android.app.*
import android.content.*
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Build
import android.os.IBinder

class GuardianService : Service() {
    companion object {
        const val CHANNEL = "guardian_monitor"
        const val ALERT_CHANNEL = "guardian_alerts"
        const val ACTION_STOP = "com.pixelguardian.app.STOP"
        @Volatile var running = false
    }
    private var receiverRegistered = false
    private var callbackRegistered = false
    private lateinit var connectivity: ConnectivityManager
    private var lastConnected: Boolean? = null
    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_OFF -> record("Screen turned off / possibly locked")
                Intent.ACTION_SCREEN_ON -> record("Screen turned on (not necessarily unlocked)")
                Intent.ACTION_USER_PRESENT -> record("User unlocked device")
            }
        }
    }
    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) = refreshConnectivity()
        override fun onLost(network: Network) = refreshConnectivity()
        override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) = refreshConnectivity()
    }
    override fun onCreate() {
        super.onCreate()
        createChannels()
        connectivity = getSystemService(ConnectivityManager::class.java)
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        startForeground(1, notification("Pixel Guardian is monitoring", "Screen and connectivity events"))
        if (!running) {
            running = true
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_SCREEN_ON)
                addAction(Intent.ACTION_USER_PRESENT)
            }
            registerReceiver(screenReceiver, filter)
            receiverRegistered = true
            lastConnected = isConnected()
            connectivity.registerDefaultNetworkCallback(networkCallback)
            callbackRegistered = true
            record("Monitoring started")
        }
        return START_STICKY
    }
    private fun isConnected(): Boolean {
        val net = connectivity.activeNetwork ?: return false
        val caps = connectivity.getNetworkCapabilities(net) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }
    private fun refreshConnectivity() {
        // A brief network handover can cause transient changes. This is informational only.
        val connected = isConnected()
        synchronized(this) {
            if (lastConnected == connected) return
            lastConnected = connected
        }
        val message = if (connected) "Network connection available" else "Network connection unavailable"
        record(message)
        if (!connected) alert(message)
    }
    private fun record(message: String) = EventStore.add(this, message)
    private fun createChannels() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel(CHANNEL, "Active monitoring", NotificationManager.IMPORTANCE_LOW))
        manager.createNotificationChannel(NotificationChannel(ALERT_CHANNEL, "Security alerts", NotificationManager.IMPORTANCE_DEFAULT))
    }
    private fun notification(title: String, body: String): Notification {
        val pending = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle(title).setContentText(body).setContentIntent(pending)
            .setOngoing(true).build()
    }
    private fun alert(message: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(2, Notification.Builder(this, ALERT_CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("Pixel Guardian alert").setContentText(message).build())
    }
    override fun onDestroy() {
        if (receiverRegistered) unregisterReceiver(screenReceiver)
        if (callbackRegistered) connectivity.unregisterNetworkCallback(networkCallback)
        running = false
        record("Monitoring stopped")
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
